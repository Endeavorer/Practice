package com.dogather.dto.dogather;

public class DogatherUserInfoDTO {
	private int dg_index;
	private int user_index;
	private String dg_user_reg_date;
	private String dg_user_target;
	private String dg_user_target_date;
	private int dp_cert_cnt;
	private int dp_feed_cnt;
	private int dpr_cnt;
	public int getDg_index() {
		return dg_index;
	}
	public void setDg_index(int dg_index) {
		this.dg_index = dg_index;
	}
	public int getUser_index() {
		return user_index;
	}
	public void setUser_index(int user_index) {
		this.user_index = user_index;
	}
	public String getDg_user_reg_date() {
		return dg_user_reg_date;
	}
	public void setDg_user_reg_date(String dg_user_reg_date) {
		this.dg_user_reg_date = dg_user_reg_date;
	}
	public String getDg_user_target() {
		return dg_user_target;
	}
	public void setDg_user_target(String dg_user_target) {
		this.dg_user_target = dg_user_target;
	}
	public String getDg_user_target_date() {
		return dg_user_target_date;
	}
	public void setDg_user_target_date(String dg_user_target_date) {
		this.dg_user_target_date = dg_user_target_date;
	}
	public int getDp_cert_cnt() {
		return dp_cert_cnt;
	}
	public void setDp_cert_cnt(int dp_cert_cnt) {
		this.dp_cert_cnt = dp_cert_cnt;
	}
	public int getDp_feed_cnt() {
		return dp_feed_cnt;
	}
	public void setDp_feed_cnt(int dp_feed_cnt) {
		this.dp_feed_cnt = dp_feed_cnt;
	}
	public int getDpr_cnt() {
		return dpr_cnt;
	}
	public void setDpr_cnt(int dpr_cnt) {
		this.dpr_cnt = dpr_cnt;
	}
	
}
