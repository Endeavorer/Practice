package com.dogather.dto.dogather;

public class DogatherUserTargetDTO {
	private int dg_index;
	private int user_index;
	private String dg_user_target_date;
	private String dg_user_target;
	public int getDg_index() {
		return dg_index;
	}
	public void setDg_index(int dg_index) {
		this.dg_index = dg_index;
	}
	public int getUser_index() {
		return user_index;
	}
	public void setUser_index(int user_index) {
		this.user_index = user_index;
	}
	public String getDg_user_target_date() {
		return dg_user_target_date;
	}
	public void setDg_user_target_date(String dg_user_target_date) {
		this.dg_user_target_date = dg_user_target_date;
	}
	public String getDg_user_target() {
		return dg_user_target;
	}
	public void setDg_user_target(String dg_user_target) {
		this.dg_user_target = dg_user_target;
	}
}
